<script>
    import Navbar from './Navbar.svelte'
    import Content from './Content.svelte'
    import Team from './Team.svelte'
    import Prices from './Prices.svelte'
</script>

<main>
    <Navbar />
    <Content />
    <Team />
    <Prices />
</main>

<style>
	
</style>